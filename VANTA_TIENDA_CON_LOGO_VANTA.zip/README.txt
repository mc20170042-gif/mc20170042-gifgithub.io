VANTA — tienda demo premium
Abre index.html en Chrome.

Incluye portada premium, buscador, filtros, ordenación, favoritos visuales,
fichas de producto, tallas/colores, carrito lateral, ofertas, newsletter
y diseño responsive para móvil.

Los productos y precios son DEMO. Para vender de verdad habrá que conectar
un sistema de pagos y configurar datos legales, envíos y productos reales.
